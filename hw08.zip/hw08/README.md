Please:

(a) list collaborators and sources of help,
(b) explain any unusual elements of your solution here, and
(c) say what, if anything you did for extra credit. (Extra credit is
    not in any way necessary!)
